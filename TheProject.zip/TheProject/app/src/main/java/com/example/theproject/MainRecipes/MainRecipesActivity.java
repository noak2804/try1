package com.example.theproject.MainRecipes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.theproject.NewRecipe.NewRecipeActivity;
import com.example.theproject.R;
import com.example.theproject.model.RecipeInformation;

import java.util.ArrayList;

public class MainRecipesActivity extends AppCompatActivity {

    MainRecipesPresenter presenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_recipes);
        presenter=new MainRecipesPresenter(this);
    }
    public void setRecycler(ArrayList<RecipeInformation> recipes)
    {
        RecyclerView recyclerView=findViewById(R.id.recycleRecipe);
        MainRecipesAdapter mainRecipesAdapter=new MainRecipesAdapter(recipes);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(mainRecipesAdapter);
    }

    public void navigatetoCreateNewRecipe()
    {
        Intent intent=new Intent(this, NewRecipeActivity.class);
        startActivity(intent);
    }
    public void createRecipe(View view) {
presenter.ToCreateNewRecipeClicked();
    }
}