package com.example.theproject.NewRecipe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.theproject.R;
import com.example.theproject.model.Ingredients;
import com.example.theproject.model.RecipeInformation;

import java.util.ArrayList;

public class NewRecipeActivity extends AppCompatActivity {
ArrayList ingredientArray =new ArrayList();
TextView nameRecipe;
TextView unit;
EditText amount;
    IngredientsPresenter presenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_recipe);
        presenter=new IngredientsPresenter(this);

    }

    public void addIngrediants(View view) {
        LinearLayout layout_ingredients=findViewById(R.id.ingerdiantLayoutRecipe);
        final View view1 = getLayoutInflater().inflate(R.layout.ingredients_recycle_recipe, null);
        layout_ingredients.addView(view1);
        ingredientArray.add(view1);

    }

    public void submitNewRecipe(View view) {
        RecipeInformation recipeInformation;

        for(int i=0;i<ingredientArray.size();i++)
        {
            nameRecipe=findViewById(R.id.nameIngred);
            unit=findViewById(R.id.unit);
            amount=(findViewById(R.id.amount));
        }
        recipeInformation=new RecipeInformation("s","sdf","k");
    }
}