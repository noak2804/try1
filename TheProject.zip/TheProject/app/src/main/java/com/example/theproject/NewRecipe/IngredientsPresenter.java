package com.example.theproject.NewRecipe;

public class IngredientsPresenter {
    NewRecipeActivity view;

    public IngredientsPresenter(NewRecipeActivity view) {
        this.view = view;

    }
}

