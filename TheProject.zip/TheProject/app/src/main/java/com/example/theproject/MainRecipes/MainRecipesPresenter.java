package com.example.theproject.MainRecipes;

import com.example.theproject.model.RecipeInformation;

import java.util.ArrayList;

public class MainRecipesPresenter {
    MainRecipesActivity view;
public MainRecipesPresenter(MainRecipesActivity view)
{
    this.view=view;
    ArrayList<RecipeInformation> recipes=new ArrayList<>(30);
    for (int i=0; i<30;i++)
    {
        recipes.add(new RecipeInformation("n","x","z"));
    }
    view.setRecycler(recipes);
}
    public void ToCreateNewRecipeClicked()
    {
        view.navigatetoCreateNewRecipe();
    }
}
